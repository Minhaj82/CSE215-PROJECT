
package labproject;

import java.util.Scanner;

public class lab {
    
    public static void lablrdr()
    {
        Moneyricipt [] m = new Moneyricipt[50];
        lab[] l = new lab[100];
        for (int i = 0; i < 50; i++)
        {
              l[i] = new lab();
        }
            
        l[0].fecility = "1. X-ray     ";
        l[0].lab_cost = 1200;
        l[1].fecility = "2. CT Scan   ";
        l[1].lab_cost = 10490;
        l[2].fecility = "3. OR Scan   ";
        l[2].lab_cost = 6500;
        l[3].fecility = "4. Blood Bank";
        l[3].lab_cost = 500;
        
         Scanner input = new Scanner(System.in);
         int j, c1, s4 = 1,count4 = 4; 
         s4 = 1;
                        System.out.println("--------------------------------------------------------------------------------");
                        System.out.println("                    **LABORATORY SECTION**");
                        System.out.println("--------------------------------------------------------------------------------");
                        while (s4 == 1)
                        {
                            System.out.println("1.Add New Entry \n2.Existing Laboratories List");
                            c1 = input.nextInt();
                            switch (c1)
                            {
                                case 1:
                                    {
                                        l[count4].new_feci();count4++;
                                        break;
                                    }
                                case 2:
                                    {
                                        System.out.println("--------------------------------------------------------------------------------");
                                        System.out.println("Fecilities\t\t Cost");
                                        System.out.println("--------------------------------------------------------------------------------");
                                        for (j = 0; j < count4; j++) {
                                            l[j].feci_list();
                                        }
                                         //m [count4].Moneyriciptmr();count4++;
                                         
                                          break;
                                        }
                                        
                                    }
                            }
                            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
                            s4 = input.nextInt();
    }
    
    
    String fecility;
    int lab_cost;
    void new_feci()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Fecility:-");
        fecility = input.nextLine();
        System.out.print("Cost:-");
        lab_cost = input.nextInt();
    }
    void feci_list()
    {
        System.out.println(fecility + "\t\t" + lab_cost);
    }
    
}
