
package labproject;

import java.util.Calendar;

public class Calender {
    
    public static void calendercr()
    {
         String months[] = {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        };
        Calendar calendar = Calendar.getInstance();
        //System.out.println("--------------------------------------------------------------------------------");
        System.out.println("\n******************************************************************************");
        System.out.println("                       WELCOME TO HOSPITAL MANAGEMENT SYSTEM                    ");
        System.out.println( "******************************************************************************");
        System.out.print("Date: " + months[calendar.get(Calendar.MONTH)] + " " + calendar.get(Calendar.DATE) + " " + calendar.get(Calendar.YEAR));
        System.out.println("\t\t\t\t\t\tTime: " + calendar.get(Calendar.HOUR) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND));
        
    }
    
}
