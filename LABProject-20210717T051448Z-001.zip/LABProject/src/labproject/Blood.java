package labproject;

import java.util.Scanner;

class SEARCH {    
    public static String Search(Blood[] blood, String b_grp) {
        String s ="";
        int count = 0;
        for (int i = 0; i <blood.length; i++) {
            if(blood[i]==null) break;
            if (b_grp.equals(blood[i].BGROUP ))
               {
                 count++;
                 s=s+blood[i].Bname+"\n";
               }
        }
        
        System.out.println("");
        //s=(count)+"books selected | Author: "+b_grp;//+";//\n \n"+"Search Result: \n"+s;
        System.out.println(count+"books selected | Author: "+b_grp+"Search Result: "+s);

        return s;
        
	}
    
}

public class Blood {
    
    public static void bloodbankbr()
    {
        Blood[] B = new Blood[20];
        int i;
        for (i = 0; i < 20; i++)
        {
            B[i] = new Blood();
        }

        B[0].Bname = "Dr.Minhaj";
        B[0].BGROUP = "A+ ";
        B[0].Blocation = "Bashundhara";
        B[0].Bphone = "09456798327";
       
        B[1].Bname = "Dr.Vikram";
        B[1].BGROUP = "AB+";
        B[1].Blocation = "Bashundhara";
        B[1].Bphone = "09456798320";
        
        B[2].Bname = "Dr.Fhad";
        B[2].BGROUP = "O- ";
        B[2].Blocation = "Mirpur,Dhaka";
        B[2].Bphone = "09456798334";
        
        B[3].Bname = "Dr.Mahtab";
        B[3].BGROUP = "A+ ";
        B[3].Blocation = "Banani,Dhaka";
        B[3].Bphone = "01816645837";
        
        Scanner input = new Scanner(System.in);
        int j, c1, s7 = 1,count7 = 4; 
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("                      **Bloodbank**");
        System.out.println("--------------------------------------------------------------------------------");
        s7 = 1;
        
         while (s7 == 1)
         {
              System.out.println("1.Add New Entry\n2.Existing donner List");
              c1 = input.nextInt();
              switch (c1)
              {
                  case 1:
                  {
                      B[count7].new_donner();count7++;
                      break;
                  }
                  case 2:
                  {
                      System.out.println("--------------------------------------------------------------------------------");
                      System.out.println("Name\t\tGroup\t\t Address  \t\tPhone");
                      System.out.println("--------------------------------------------------------------------------------");
                      for (j = 0; j < count7; j++)
                      {
                          B[j].donner_info();   
                      }
                      System.out.println("\nEnter blood group name to Search ");
                      Scanner scanner = new Scanner(System.in);
                      
                      String b_grp = scanner.nextLine();
                      
                      SEARCH m = new SEARCH();
            
                      System.out.println(m.Search(B,b_grp));
                      break;
                  }
              }
              System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
              s7 = input.nextInt();
         }
    }

    String Bname, BGROUP, Blocation, Bphone;
    void new_donner()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Name:-");
        Bname = input.nextLine();
        System.out.print("Group:-");
        BGROUP = input.nextLine();
        System.out.print("Address:-");
        Blocation = input.nextLine();
        System.out.print("Phone:-");
        Bphone = input.nextLine();
        
    }
    void donner_info()
    {
        System.out.println(Bname + "  \t" + BGROUP + "      \t" + Blocation + "    \t" + Bphone );
    }   
}
