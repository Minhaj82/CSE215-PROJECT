
package labproject;

import java.util.Scanner;


public class Moneyricipt {
    
    public static void Moneyriciptmr()
    {
    //User+++++++++++++++++++++++++++++++++++++++++++++++++++++++
    Scanner input = new Scanner(System.in);
    System.out.println("if you take a test please Choose your option");
    //int choice1, j;
    int e1, t1 = 1;
    int s7 = 1;
    //choice1 = input.nextInt();
        while(s7 == 1)
        {
            System.out.println("Which fecilities you want to take");
            e1 = input.nextInt();
            switch(e1)
            {
                case 1:
                {
                    int Xray  = 1200; 
                    System.out.println("\t\tMONEY RICIPT\t\t");
                    System.out.println("Your test name  is           X-ray ");
                    System.out.println("Your test Serials is:        82");
                    System.out.println("Room Number:                 X-ra306");
                    System.out.printf("Your total test ammount is:  %dTk\n",Xray);
                    System.out.println("=====================================  ");
                    System.out.println("Please pay                   1200Tk");
                }
                break;
                case 2:
                {
                    int CTScan = 10490; 
                    System.out.println("\t\tMONEY RICIPT\t\t");
                    System.out.println("Your test name  is           CT Scan ");
                    System.out.println("Your test Serials is:        12");
                    System.out.println("Room Number:                 CT805");
                    System.out.printf("Your total test ammount is:  %dTk\n",CTScan);
                    System.out.println("=====================================  ");
                    System.out.println("Please pay                   10490Tk");
                
               }
                
                break;
                
                case 3:
                {
                    int ORScan = 6500; 
                    System.out.println("\t\tMONEY RICIPT\t\t");
                    System.out.println("Your test name  is           OR Scan ");
                    System.out.println("Your test Serials is:        07");
                    System.out.println("Room Number:                 OR906");
                    System.out.printf("Your total test ammount is:  %dTk\n",ORScan);
                    System.out.println("=====================================  ");
                    System.out.println("Please pay                   6500Tk");
                }
                
                break;
                
                case 4:
                {
                    int Bbank = 10490; 
                    System.out.println("\t\tMONEY RICIPT\t\t");
                    System.out.println("Your test name  is           Blood ");
                    System.out.println("Your test Serials is:        03");
                    System.out.println("Room Number:                 B601");
                    System.out.printf("Your total test ammount is:  %dTk\n",Bbank);
                    System.out.println("=====================================  ");
                    System.out.println("Please pay                   500Tk");
                }
                break;
            }
            System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
            s7 = input.nextInt();
        }
        
    }
}
