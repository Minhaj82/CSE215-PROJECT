
package labproject;

import java.util.Scanner;


public class Main {
    
    public static void Main()
    {
        Calender c = new Calender();
        c.calendercr();
        
        doctor[] d = new doctor[150];
        patient[] p = new patient[250];
        lab[] l = new lab[100];
        fecility[] f = new fecility[50];
        medicine[] m = new medicine[750];
        staff[] s = new staff[200];
        Blood[] B = new Blood[150];
        STANDINGS[] S = new STANDINGS[20];
        
        int count1 = 4, count2 = 4, count3 = 4, count4 = 4, count5 = 4, count6 = 4,count7 = 4,count8 = 4;
        String Username, Password;
        Username = "Admin"; Password = "admin";

        Scanner input1 = new Scanner(System.in);
        System.out.print("\nEnter Username: ");
        String username = input1.next();

        Scanner input2 = new Scanner(System.in);
        System.out.print("\nEnter Password : ");
        String password = input2.next();

        if (username.equals(Username) && password.equals(Password)) 
        {
            System.out.println("\n                           Access Granted! \n******************************Welcome!************************");
       
        Scanner input = new Scanner(System.in);
        int choice, j, c1, status = 1, s1 = 1, s2 = 1, s3 = 1, s4 = 1, s5 = 1, s6 = 1,s7 = 1,S8 = 1;
        while (true)
        {
            System.out.println("\n                                           MAIN MENU");
            System.out.println("=================================================================================================================");
            System.out.println("1.Doctos   2.Patients   3.Medicines   4.Laboratories   5.Facilities   6.Staff   7.Blood Bank  8.STANDINGS 9.Exit ");
            System.out.println("=================================================================================================================");
            choice = input.nextInt();
            switch (choice)
            {
                case 1:
                    {
                        d[count1].doctordr();//count1++;
                        //System.out.flush(); 
                        break;
                    }
                case 2:
                    {
                        p[count2].patientpr();//count2++;
                        break;
                    }
                case 3:
                    {
                        m[count3].medicinemr();//count3++;
                        break;
                    }
                case 4:
                    {
                        l[count4].lablrdr();//count4++;
                        break;
                    }
                case 5:
                    {
                        f[count5].fecilityfr();//count5++;
                        break;
                    }
                case 6:
                    {
                        s[count6].staffsr(); count6++;
                        break;
                    }
                case 7:
                    {
                        B[count7].bloodbankbr(); count7++;
                        break;
                    }
                case 8:
                    {
                        S[count8].STANDINGSsr(); count8++;
                        break;
                    }
                case 9:
                {
                    System.exit(0);
                    break;
                }
                default:
                    {
                        System.out.println(" You Have Enter Wrong Choice!!!");
                    }
            }
            System.out.println("\nReturn to MAIN MENU Press 1");
            //System.out.flush();
            status = input.nextInt();
        }
      
    }
        else if (username.equals(Username)) 
       {
           System.out.println("Invalid Password!");
       } 
        else if (password.equals(Password)) 
       {
           System.out.println("Invalid Username!");
       } 
       else 
       {
           System.out.println("Invalid Username & Password!");
       }
        //System.out.flush();
        //status = input.nextInt(); 
    }
}
