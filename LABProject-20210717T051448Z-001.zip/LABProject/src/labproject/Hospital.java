package labproject;

public class Hospital 
{
    public static void main(String[] args) 
    {
        Main m = new Main();
        m.Main();
    }
}