
package labproject;

import java.util.Scanner;

public class doctor {
    
    public static void doctordr()
    {
        doctor[] d = new doctor[150];
        int i;
        for (i = 0; i < 100; i++)
        {
            d[i] = new doctor();
        }
        d[0].dname = "Dr.Ghanendra";
        d[0].did = "21";
        d[0].specilist = "ENT";
        d[0].appoint = "05:00-11:00AM";
        d[0].doc_qual = "MBBS,MD";
        d[0].droom = 17;
        d[1].did = "32";
        d[1].dname = "Dr.Vikram";
        d[1].specilist = "Physician";
        d[1].appoint = "10:00-03:00AM";
        d[1].doc_qual = "MBBS,MD";
        d[1].droom = 45;
        d[2].did = "17";
        d[2].dname = "Dr.Rekha";
        d[2].specilist = "Surgeon";
        d[2].appoint = "08:00-02:00AM";
        d[2].doc_qual = "BDM  ";
        d[2].droom = 8;
        d[3].did = "33";
        d[3].dname = "Dr.Pramod";
        d[3].specilist = "Artho";
        d[3].appoint = "10:00-04:00PM";
        d[3].doc_qual = "MBBS,MS";
        d[3].droom = 40;
        
         Scanner input = new Scanner(System.in);
         int j, c1, s1 = 1,count1 = 4; 
         System.out.println("--------------------------------------------------------------------------------");
         System.out.println("                      **DOCTOR SECTION**");
         System.out.println("--------------------------------------------------------------------------------");
         s1 = 1;
         //System.out.flush(); 
         while (s1 == 1)
         {
              System.out.println("1.Add New Entry\n2.Existing Doctors List");
              c1 = input.nextInt();
              switch (c1)
              {
                  case 1:
                  {
                      d[count1].new_doctor();count1++;
                      break;
                  }
                  case 2:
                  {
                      System.out.println("--------------------------------------------------------------------------------");
                      System.out.println("id \t Name\t\tSpecilist \t Timing \t\tQualification \t Room No.");
                      System.out.println("--------------------------------------------------------------------------------");
                      for (j = 0; j < count1; j++)
                      {
                          d[j].doctor_info();
                         // System.out.flush(); 
                      }
                      break;
                  }
              }
              System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
              s1 = input.nextInt(); 
         }
    }    
    String did, dname, specilist, appoint, doc_qual;
    int droom;
    
    void new_doctor()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Id:-");
        did = input.nextLine();
        System.out.print("Name:-");
        dname = input.nextLine();
        System.out.print("Specilization:-");
        specilist = input.nextLine();
        System.out.print("Work time:-");
        appoint = input.nextLine();
        System.out.print("Qualification:-");
        doc_qual = input.nextLine();
        System.out.print("Room no:-");
        droom = input.nextInt();
    }
    void doctor_info()
    {
        System.out.println(did + "\t" + dname + "  \t" + specilist + "     \t" + appoint + "    \t" + doc_qual + "       \t" + droom);
    }   
}