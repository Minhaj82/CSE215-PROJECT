package SwingGUI;

import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

class LoginFrame extends JFrame implements ActionListener {
	
    Container container = getContentPane();
    
    //Application Label
    JLabel appLabel = new JLabel("facebook");
    JLabel designLabel = new JLabel("------------------------OR------------------------");
    
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    
    JCheckBox showPassword = new JCheckBox("Show Password");
    
    JButton loginButton = new JButton("Login");
    JButton registrationButton = new JButton("Sign Up");

    LoginFrame() {
    	//#Notes
    // setBounds(int Xaxis, int Yaxis, int width, int height)
    	
    	this.setTitle("Facebook");
    	this.setBounds(500, 100, 400, 600);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        
        //Set App Icon here
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\JavaWorkspace\\NSU\\src\\SwingGUI\\icon.png"));
    	
    	Initialize();
        addActionEvent();
        
    }
    
    public void Initialize()
    {
    	
    	//#Notes
    	// setBounds(int Xaxis, int Yaxis, int width, int height)
    	
    	//# Container
    	//set default layout to null (no components)
    	container.setLayout(null);
    	container.setBackground(Color.BLUE);
    	
    	//# Labels
    	appLabel.setBounds(92, 82, 192, 56);//set Location and size
    	appLabel.setForeground(new Color(255, 255, 255));//set text color
    	appLabel.setFont(new Font("San Francisco", Font.BOLD, 30));
    	appLabel.setHorizontalAlignment(SwingConstants.CENTER);
    	container.add(appLabel);//add the component to container
    	
    	
    	designLabel.setFont(new Font("San Francisco", Font.BOLD, 16));
    	designLabel.setBounds(15, 455, 364, 29);
    	designLabel.setHorizontalAlignment(SwingConstants.CENTER);
    	designLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		container.add(designLabel);
		
		
        //# Text Fields
        //userTextField.setBounds(150, 150, 150, 30);
        userTextField.setBounds(42, 185, 312, 37);
        userTextField.setToolTipText("Enter Username");
        userTextField.setFont(new Font("San Francisco", Font.PLAIN, 16));
        container.add(userTextField);
        
        //passwordField.setBounds(150, 220, 150, 30);
        passwordField.setToolTipText("Enter Password");
        passwordField.setFont(new Font("San Francisco", Font.PLAIN, 16));
        passwordField.setBounds(40, 258, 314, 37);
        container.add(passwordField);
        
        //# Check Boxes
        showPassword.setBounds(360, 267, 20, 20);
        showPassword.setBackground(Color.BLUE);
        showPassword.setToolTipText("Show Password");
        container.add(showPassword);
        
        //# Buttons
        loginButton.setBounds(145, 354, 97, 26);
        loginButton.setHorizontalTextPosition(SwingConstants.CENTER);
        loginButton.setVerticalTextPosition(SwingConstants.CENTER);
        loginButton.setBackground(new Color(255, 255, 255));
        loginButton.setFont(new Font("San Francisco", Font.BOLD, 17));
        container.add(loginButton);
        
        registrationButton.setBounds(135, 493, 115, 29);
        registrationButton.setBackground(new Color(90, 252, 3));
        registrationButton.setFont(new Font("San Francisco", Font.BOLD, 17));
        container.add(registrationButton);
		
    }

    public void addActionEvent() {
        loginButton.addActionListener(this);
        registrationButton.addActionListener(this);
        showPassword.addActionListener(this);
    }
    
    public void reset()
    {
    	userTextField.setText("");
    	passwordField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            
        	String userText;
            String passText;
            
            userText = userTextField.getText();
            passText = passwordField.getText();
            
			try {
				String path = "F://JavaWorkspace//NSU//src//SwingGUI/UserInfo.txt";
				
				//Scanner get = new Scanner(new File(path));
				
				FileReader fr = new FileReader(path);
	            BufferedReader br = new BufferedReader(fr);
	            
	            boolean isLoginSuccess = false,isfromNSU=false;
	            int u=0;
	            String line, fuserEmail, fpass, fuserID;
	            
	            
	            //while ((line = get.nextLine()) != null)
	            while((line = br.readLine()) != null)
	            {	
	            	fuserEmail = line.split(" ")[2];
	                fpass = line.split(" ")[3];
	                
	                fuserID = fuserEmail.split("@")[0];
	                //System.out.println(fuserID);
	                
	                if(fuserEmail.split("@")[1].equalsIgnoreCase("northsouth.edu"))
	                {
	                	isfromNSU = true;
	                }
	                
	                
	                if ((fuserID.equalsIgnoreCase(userText) || fuserEmail.equalsIgnoreCase(userText)) && fpass.equalsIgnoreCase(passText)) {
	                	isLoginSuccess = true;
	                	
	                	this.setVisible(false);
		                
	                	HomePage dashboard = new HomePage(fuserEmail);
		                dashboard.setVisible(true);
	    				
		                break;
	                }
	                else if(fuserID.equalsIgnoreCase(userText) || fuserEmail.equalsIgnoreCase(userText))
	                {
	                	u++;
	                }    
	            }
	            if(!isLoginSuccess)
	            {
	            	if(u>0)
	            	{
	            		JOptionPane.showMessageDialog(null, "Invalid Password!", "WARNING!!", JOptionPane.WARNING_MESSAGE);
	            	}
	            	else
	            	{
	            		JOptionPane.showMessageDialog(null, "Invalid User!", "WARNING!!", JOptionPane.WARNING_MESSAGE);
	            	}
	            }
	            
	            fr.close();
	            //get.close();
				
			}
			catch (Exception ep) {
				System.out.println("ERROR 404! File-Not-Found");
	            //ep.printStackTrace();
	        }
        }
        
        if (e.getSource() == registrationButton) {
        	this.setVisible(false);
            SignUpFrame s = new SignUpFrame();
            s.setVisible(true);
        }
        if (e.getSource() == showPassword) 
        {
        	//int d = passwordField.getEchoChar();
        	
            if (showPassword.isSelected()) 
            {
                passwordField.setEchoChar((char) 0);
            }
            else 
            {
                passwordField.setEchoChar((char) 8226);
            }
        }
    }

}