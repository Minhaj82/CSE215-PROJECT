package SwingGUI;

public class Main {
    public static void main(String[] a) {
    	
        LoginFrame lframe = new LoginFrame();
        lframe.setVisible(true);

    }

}
