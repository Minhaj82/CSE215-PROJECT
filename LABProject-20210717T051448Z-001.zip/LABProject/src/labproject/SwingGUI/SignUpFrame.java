package SwingGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class SignUpFrame extends JFrame implements ActionListener
{
	String path = "F://JavaWorkspace//NSU//src//SwingGUI/UserInfo.txt";
    
	Container sContainer = getContentPane();
	
	JLabel bgImage = new JLabel(new ImageIcon("F:\\JavaWorkspace\\NSU\\src\\SwingGUI\\signup.png"));
	
	JTextField fnTextField = new JTextField();
	JTextField lnTextField = new JTextField();
	JTextField idTextField = new JTextField();
	
	JPasswordField passwordField = new JPasswordField();
	
    JCheckBox showPassword = new JCheckBox();
    
    JButton regButton = new JButton("Create Account");
    JButton loginButton = new JButton("Log in");

	public SignUpFrame()
	{
		this.setTitle("Facebook - Sign Up");
        this.setBounds(300, 80, 800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\JavaWorkspace\\NSU\\src\\SwingGUI\\icon.png"));
	
		Initialize();
        addActionEvent();
	}
	
	public void Initialize()
	{
		sContainer.setLayout(null);
		
		fnTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		fnTextField.setBounds(498, 182, 270, 28);
        fnTextField.setToolTipText("First name");
        fnTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
        sContainer.add(fnTextField);
        
        lnTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		lnTextField.setBounds(498, 242, 270, 28);
        lnTextField.setToolTipText("Last name");
        lnTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
        sContainer.add(lnTextField);
        
        idTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        idTextField.setBounds(498, 302, 270, 28);
        idTextField.setToolTipText("Email address");
        idTextField.setFont(new Font("San Francisco", Font.PLAIN, 15));
        sContainer.add(idTextField);
        
        passwordField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        passwordField.setBounds(498, 362, 270, 28);
        passwordField.setToolTipText("Password");
        passwordField.setFont(new Font("San Francisco", Font.PLAIN, 15));
        sContainer.add(passwordField);
        
        showPassword.setBounds(770, 371, 20, 20);
        showPassword.setBackground(Color.WHITE);
        showPassword.setToolTipText("Show Password");
        sContainer.add(showPassword);
        
        regButton.setBounds(497, 425, 268, 37);
        regButton.setBorderPainted(false);
        regButton.setBackground(new Color(59,89,155));
        regButton.setForeground(Color.WHITE);
        regButton.setFont(new Font("San Francisco", Font.BOLD, 15));
        sContainer.add(regButton);
        
        loginButton.setBounds(685, 468, 78, 40);
        loginButton.setBorderPainted(false);
        loginButton.setBackground(Color.WHITE);
        loginButton.setForeground(new Color(59,89,155));
        loginButton.setFont(new Font("San Francisco", Font.BOLD, 14));
        sContainer.add(loginButton);
        
        bgImage.setBounds(0, 0, 800, 600);
		bgImage.setHorizontalAlignment(SwingConstants.CENTER);
		bgImage.setOpaque(true);
		sContainer.add(bgImage);
        
	}
	
	public void addActionEvent()
	{
		loginButton.addActionListener(this);
        regButton.addActionListener(this);
        showPassword.addActionListener(this);
	}
	
	public boolean check(String email)
	{
		String line;
		try {
			FileReader fr = new FileReader(path);
	        BufferedReader br = new BufferedReader(fr);
	        
	        while ((line = br.readLine()) != null)
	        {
	        	if(email.split("@")[0].equalsIgnoreCase(line.split(" ")[2].split("@")[0]))
	        	{
	        		return true;
	        	}
	        }
		}
		catch (Exception ep) {
			System.out.println("ERROR 404! File-Not-Found");
            //ep.printStackTrace();
        }
		return false;
	}
	
	@Override
    public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource() == loginButton) 
		{
			this.setVisible(false);
			LoginFrame l = new LoginFrame();
			l.setVisible(true);
		}
		if (e.getSource() == regButton) 
		{
			try
			{
			      if(!check(idTextField.getText()))
			      {
			    	  
			    	  FileWriter myWriter = new FileWriter(path,true);
			    	  myWriter.write(fnTextField.getText()+" "+lnTextField.getText()+" "+idTextField.getText()+" "+passwordField.getText()+"\n");
				      myWriter.close();
				      JOptionPane.showMessageDialog(null, "Successfully Registered! Please Login to continue...","Confirmation", JOptionPane.WARNING_MESSAGE);
			      }
			      else
			      {
			    	  JOptionPane.showMessageDialog(null, "Username already in use!","Confirmation", JOptionPane.WARNING_MESSAGE);
			      }
			 }
			catch (IOException ep) {
			      System.out.println("ERROR 404! File-Not-Found");
			      ep.printStackTrace();
			    }
		}
		if (e.getSource() == showPassword) 
        {
			//int d = passwordField.getEchoChar();
            if (showPassword.isSelected()) 
            {
                passwordField.setEchoChar((char) 0);
            }
            else 
            {
                passwordField.setEchoChar((char) 8226);
            }
        }
	}
}