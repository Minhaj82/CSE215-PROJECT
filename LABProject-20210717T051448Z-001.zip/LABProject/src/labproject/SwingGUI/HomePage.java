package SwingGUI;

import javax.swing.*;

import java.awt.Container;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage extends JFrame implements ActionListener{
	Container container = getContentPane();
	JTextField userTextField = new JTextField();
	public HomePage(String email)
	{
		userTextField.setBounds(42, 185, 312, 37);
        userTextField.setToolTipText("Enter Username");
        userTextField.setFont(new Font("San Francisco", Font.PLAIN, 16));
        container.add(userTextField);
        userTextField.setText(email);
        /*
		if(edu)
		{
			this.setTitle("North South University");
		}
		else
		{
			this.setTitle("Facebook");
		}*/
		
    	this.setBounds(500, 100, 400, 600);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        
        //Set App Icon here
        this.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\JavaWorkspace\\NSU\\src\\SwingGUI\\icon.png"));
	}
	@Override
    public void actionPerformed(ActionEvent e) {
		
	}
}
