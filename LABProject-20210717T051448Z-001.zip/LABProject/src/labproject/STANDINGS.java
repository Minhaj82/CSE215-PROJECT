package labproject;

import java.util.Scanner;

public class STANDINGS {  
    
    public static void STANDINGSsr()
    {
        
        STANDINGS[] S = new STANDINGS[20];
        int i;
        for (i = 0; i < 20; i++)
        {
            S[i] = new STANDINGS();
        }

        S[0].Bname = "liverpool";
        S[0].BP = "14 ";
        S[0].BW = "9";
        S[0].BL = "1";
        S[0].BPTS = "31";
       
        S[1].Bname = "Man. City";
        S[1].BP = "14";
        S[1].BW = "7";
        S[1].BL = "2";
        S[1].BPTS = "26";
        
        S[2].Bname = "Chelsea ";
        S[2].BP = "15";
        S[2].BW = "7";
        S[2].BL = "4";
        S[2].BPTS = "25";
        
        S[3].Bname = "Everton";
        S[3].BP = "15";
        S[3].BW = "9";
        S[3].BL = "4";
        S[3].BPTS = "29";
        
        Scanner input = new Scanner(System.in);
        int j, c1, s8 = 1,count8 = 4;
        
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("                             **STANDINGS**");
        System.out.println("--------------------------------------------------------------------------------");
        s8 = 1;
        
        while (s8 == 1)
         {
              System.out.println("1.Add New Entry\n2.Existing Club List");
              c1 = input.nextInt();
              switch (c1)
              {
                  case 1:
                  {
                      S[count8].new_CLUB();count8++;
                      break;
                  }
                  case 2:
                  {
                      System.out.println("--------------------------------------------------------------------------------");
                      System.out.println("Club name\tMP\tW\tL\tpts");
                      System.out.println("--------------------------------------------------------------------------------");
                      for (j = 0; j < count8; j++)
                      {
                          S[j].CLUB_info();
                          
                      }
                      break;
                  }
              }
              System.out.println("\nReturn to Back Press 1 and for Main Menu Press 0");
              s8 = input.nextInt();
         }
    }

    String Bname,BP, BW, BL,BPTS;
    void new_CLUB()
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Name:-");
        Bname = input.nextLine();
        System.out.print("MP:-");
        BP = input.nextLine();
        System.out.print("W:-");
        BW = input.nextLine();
        System.out.print("L:-");
        BL = input.nextLine();
        System.out.print("Pts:-");
        BPTS = input.nextLine();
        
    }
    void CLUB_info()
    {
        System.out.println(Bname + "  \t" + BP + "\t" + BW + "\t" + BL +"\t"+BPTS );
    }   
}
